﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.OleDb;

namespace test
{
    class Program
    {
        
        static void Main(string[] args)
        {
            List<Books> list_books = new List<Books>();
         
            for (; ; )
            {
             
                Console.WriteLine("Выберите действие: \n1 - Добавить книгу \n2 - Показать всех авторов \n3 - Показать все книги \n4 - Вывести все творчество автора \n5 - Удалить книгу \n0 - Выход");
                int choose = int.Parse(Console.ReadLine());
                switch (choose)
                {
                    case 1:
                        {                            
                            Console.Clear();
                            list_books.Add(new Books());
                            Console.Clear();
                            break;
                        }
                    case 2:
                        {
                            Books.ShowAuthors();
                            break;
                        }
                    case 3:
                        {
                            
                            Books.GetBooksList();
                            Console.WriteLine();
                            break;
                        }
                    case 4: //ВСЕ КНИГИ АВТОРА
                        {
                            Books.AuthorsBook();
                            break;
                        }
                    case 5:
                        {
                            Books.DeleteBooks();
                            break;
                        }
                    case 0:
                        {                            
                            Environment.Exit(0);
                            break;
                        }
                }
            }
        }
       

    }
}
