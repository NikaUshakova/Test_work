﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.OleDb;

namespace test
{
    class Books
    {
        public string Name_book { get; set; }
        int year;
        public string Surname_author { get; set; }


        public int Year
        {
            get
            {
                return year;
            }
            set
            {
                if (value < 0)
                    year = 1950;
                else year = value;
            }
        }

        
        public Books()
        {
            EnterInfo();
        }
        public Books(string Name_book, int Year,string Surname_author)
        {
            this.Name_book = Name_book;
            this.Year = Year;
            this.Surname_author = Surname_author;
        }

        public void EnterInfo()
        {
            
           bool check = false;
            
                Console.WriteLine("Введите название книги: ");
                Name_book = Console.ReadLine();
                
                while (Name_book.Length > 30)
                {
                    Console.WriteLine("Введите название до 30 символов");
                    Console.WriteLine("Введите название книги: ");
                    Name_book = Console.ReadLine();
                    
                }
            
            int count = 0;
            Console.WriteLine("Сколько авторов книги: ");
           
            while (check == false)
            {
                try
                {
                    count = int.Parse(Console.ReadLine());
                    check = true;
                }
                catch
                {
                    Console.WriteLine("Введите корректное значение(целочисленный тип)");
                   
                }
            }

            for (int i = 0; i < count; i++)
            {
                Console.WriteLine("Введите фамилию автора книги: ");
                Surname_author = Console.ReadLine();
                while (Surname_author.Length > 20)
                {
                    Console.WriteLine("Фамилия должна быть до 20 символов");
                    Console.WriteLine("Введите фамилию автора: ");
                    Surname_author = Console.ReadLine();

                }
            }
            Console.WriteLine("Введите год издания: ");
            check = false;
            while (check == false)
            {
                try
                {
                    Year = int.Parse(Console.ReadLine());
                    check = true;
                }
                catch
                {
                    Console.WriteLine("Введите корректное значение(целочисленный тип)");
                }
            }

            OleDbConnection con = new OleDbConnection();
            OleDbCommand cmd = new OleDbCommand();
            con.ConnectionString = ConfigurationManager.ConnectionStrings["Connection"].ToString();
            con.Open();
            cmd.Connection = con;
            cmd.CommandText = "insert into books (Название, Автор, [Год издания]) values('" + Name_book + "','" + Surname_author + "'," + Year + ")";
            cmd.ExecuteNonQuery();
            Console.WriteLine("ДОБАВЛЕНО");
        }
        //public string GetInfo()
        //{           
        //     return "Название: " + Name_book + " Год издания: " + Year + " Автор: " + Surname_author + " ";
        //}

        public static void GetBooksList()
        {

            string connString = ConfigurationManager.ConnectionStrings["Connection"].ConnectionString;
            using (OleDbConnection con = new OleDbConnection(connString))
            {
                using (OleDbCommand cmd = new OleDbCommand("SELECT * FROM [books]", con))
                {
                    con.Open();
                    OleDbDataReader reader = cmd.ExecuteReader();
                    Console.WriteLine("Список книг:");
                    int i=1;
                    while (reader.Read())
                    {
                            
                                Console.WriteLine((i++)+ ") Название: " + reader.GetString(0) + ", Автор: " + reader.GetString(1) + ", Год: " + reader.GetString(2));
                                Console.WriteLine("------------------------------------------------------------");
                            
                     }

                    reader.Close();
                }
            }
        }

        public static void ShowAuthors()
        {
            string connString = ConfigurationManager.ConnectionStrings["Connection"].ConnectionString;
            using (OleDbConnection con = new OleDbConnection(connString))
            {
                using (OleDbCommand cmd = new OleDbCommand("SELECT books.Автор FROM [books]", con))
                {
                    int i = 1;
                    con.Open();
                    OleDbDataReader reader = cmd.ExecuteReader();
                    Console.WriteLine("Список авторов:");
                    while (reader.Read())
                    {
                           Console.WriteLine((i++)+") Автор: " + reader.GetString(0));
                            Console.WriteLine("-----------------------------------");
                       
                        
                    }

                    reader.Close();
                }
            }
        }

        public static void ShowBooks()
        {
            string connString = ConfigurationManager.ConnectionStrings["Connection"].ConnectionString;
            
        }

        public static void DeleteBooks()
        {
            string connString = ConfigurationManager.ConnectionStrings["Connection"].ConnectionString;
            using (OleDbConnection con = new OleDbConnection(connString))
            {
                using (OleDbCommand cmd = new OleDbCommand("SELECT books.Название FROM [books]", con))
                {
                    con.Open();
                    OleDbDataReader reader = cmd.ExecuteReader();
                    int i = 1;
                    while (reader.Read())
                    {
                        Console.WriteLine((i++)+ ") Книга: " + reader.GetString(0));                        
                    }
                    reader.Close();
                }
            }

            Console.WriteLine("Введите название книги, которую надо удалить? ");
            string n = Console.ReadLine();
            
            using (OleDbConnection con = new OleDbConnection(connString))
            {
                using (OleDbCommand cmd = new OleDbCommand("delete from  [books] WHERE books.[Название] = '"+ n+"';", con))
                {
                    int i = 1;
                    con.Open();
                    OleDbDataReader reader = cmd.ExecuteReader();
                   

                    reader.Close();
                }
            }
        }

        public static void AuthorsBook()
        {
            Console.WriteLine("Введите фамилию автора!");
            string s = Console.ReadLine();
            string connString = ConfigurationManager.ConnectionStrings["Connection"].ConnectionString;
            using (OleDbConnection con = new OleDbConnection(connString))
            {
                using (OleDbCommand cmd = new OleDbCommand("SELECT [Название] FROM [books] WHERE books.[Автор] = '" + s+ "';" , con))
                {
                    con.Open();
                    OleDbDataReader reader = cmd.ExecuteReader();
                    int i = 1;
                    while (reader.Read())
                    {
                        Console.WriteLine((i++) + ")Название: " + reader.GetString(0));
                        
                    }

                    reader.Close();
                }
            }
        }
    }
}
